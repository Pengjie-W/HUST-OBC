import json

# 要保存的列表
my_list = ['1.png','2.png']

# 指定保存的文件路径
file_path = "use.json"

# 使用json.dump将列表保存到文件
with open(file_path, 'w',encoding='utf8') as json_file:
    json.dump(my_list, json_file)
